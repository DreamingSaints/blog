Ball-Aqua Press Kit
===================

Contents
--------
screenshots/     Current store screenshots (01 is the lead still)
steam/           Store & library capsules, icons, logos
achievements/    Steam achievement icons (256x256 locked + unlocked PNGs)
fonts/           MuseoModerno logo font (variable TTF, OFL license)
trailer/         Current official trailer (the same master used on Steam)

Gameplay loops (MP4) are hosted separately:
https://github.com/DreamingSaints/blog/tree/main/096/clips
01-lily-pond.mp4 is the lead loop.

Free to use in videos, articles, and social posts.

Steam: https://store.steampowered.com/app/4967660/BallAqua
Demo:  https://store.steampowered.com/app/5011940/BallAqua_Demo
