Ball-Aqua Press Kit
===================

Contents
--------
screenshots/     Gameplay + UI screenshots
steam/           Store & library capsules, icons, logos
achievements/    Achievement icons (locked / unlocked)

Gameplay clips (GIF + MP4) are hosted separately (too large for this ZIP):
https://github.com/DreamingSaints/blog/tree/main/096/clips

Free to use in videos, articles, and social posts.

Steam: https://store.steampowered.com/app/4967660/BallAqua
Demo:  https://store.steampowered.com/app/5011940/BallAqua_Demo
