Ball-Aqua Press Kit
===================

screenshots/    Gameplay screenshots
steam/          Steam capsules, icons, logos
achievements/   Achievement icons

Gameplay GIFs + MP4s (too large for one ZIP on GitHub):
https://github.com/DreamingSaints/blog/tree/main/096/clips

Direct GIF 4 (email / social):
https://github.com/DreamingSaints/blog/raw/main/096/ball-aqua-4.gif

Free to use in videos, articles, and social posts.
Steam: https://store.steampowered.com/app/4967660/BallAqua
Demo:  https://store.steampowered.com/app/5011940/BallAqua_Demo
