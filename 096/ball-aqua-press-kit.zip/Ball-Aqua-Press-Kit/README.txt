Ball-Aqua Press Kit
===================

Contents
--------
screenshots/     Gameplay screenshots (01-05)
steam/           Store & library capsules, icons, logos
achievements/    Achievement icons (locked / unlocked)

Free to use in videos, articles, and social posts.

Steam: https://store.steampowered.com/app/4967660/BallAqua
Demo:  https://store.steampowered.com/app/5011940/BallAqua_Demo
