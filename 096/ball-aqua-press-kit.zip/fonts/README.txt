Ball-Aqua Logo Font
===================

MuseoModerno variable font, weights 100–900.
The Ball-Aqua logo uses ExtraBold (weight 800).

The font is provided for accurately reproducing Ball-Aqua branding in
press coverage, videos, thumbnails, and editorial graphics.

Copyright 2020 The MuseoModerno Project Authors
https://github.com/Omnibus-Type/MuseoModerno

Licensed under the SIL Open Font License, Version 1.1.
See OFL.txt in this folder.
